PHP Example Code

Example1 - PHP4 using the domxml extension to parse the results.
Example2 - PHP4 using domxml and xpath
Example3 - PHP5 using dom
Example4 - PHP5 using SimpleXML
Example5 - PHP5 using SimpleXML and a cache layer

References

PHP4 domxml    - http://php.net/domxml
PHP4 xpath     - http://php.net/domxml
PHP5 dom       - http://php.net/dom
PHP5 SimpleXML - http://php.net/simplexml
