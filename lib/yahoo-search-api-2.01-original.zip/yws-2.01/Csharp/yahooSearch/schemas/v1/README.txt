
The Schema files can be obtained from
http://developer.yahoo.com/search
by looking in the desired Web Service documentation