"""Unit tests for all yahoo.search.image classes

"""

import unittest
from searchbase import SearchServiceTest

from yahoo.search.image import *


__revision__ = "$Id: image.py,v 1.1 2005/10/17 01:41:47 zwoop Exp $"
__version__ = "$Revision: 1.1 $"
__author__ = "Leif Hedstrom <leif@ogre.com>"
__date__ = "Sun Oct 16 18:40:34 PDT 2005"


#
# Test for image search
#
class ImageSearchTestCase(SearchServiceTest, unittest.TestCase):
    """ImageSearchTestCase - ImageSearch Unit tests.
    """
    SERVICE = ImageSearch
    NUM_PARAMS = 8


#
# Finally, run all the tests
#
if __name__ == '__main__':
    unittest.main()



#
# local variables:
# mode: python
# indent-tabs-mode: nil
# py-indent-offset: 4
# end:
