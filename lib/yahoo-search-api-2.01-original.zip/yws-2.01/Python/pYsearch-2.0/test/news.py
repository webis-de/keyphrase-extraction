"""Unit tests for all yahoo.search.news classes

"""

import unittest
from searchbase import SearchServiceTest

from yahoo.search.news import *


__revision__ = "$Id: news.py,v 1.2 2005/10/27 02:59:15 zwoop Exp $"
__version__ = "$Revision: 1.2 $"
__author__ = "Leif Hedstrom <leif@ogre.com>"
__date__ = "Wed Oct 26 19:45:35 PDT 2005"


#
# Test for news search
#
class NewsSearchTestCase(SearchServiceTest, unittest.TestCase):
    """NewsSearchTestCase - NewsSearch Unit tests.
    """
    SERVICE = NewsSearch
    NUM_PARAMS = 7


#
# Finally, run all the tests
#
if __name__ == '__main__':
    unittest.main()



#
# local variables:
# mode: python
# indent-tabs-mode: nil
# py-indent-offset: 4
# end:
