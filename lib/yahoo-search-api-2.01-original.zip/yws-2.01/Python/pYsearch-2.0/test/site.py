"""Unit tests for all yahoo.search.web classes

"""

import unittest
from searchbase import SearchServiceTest

from yahoo.search.site import *


__revision__ = "$Id: site.py,v 1.1 2005/10/27 18:07:59 zwoop Exp $"
__version__ = "$Revision: 1.1 $"
__author__ = "Leif Hedstrom <leif@ogre.com>"
__date__ = "Thu Oct 27 11:00:26 PDT 2005"


#
# Test for PageData
#
class PageDataTestCase(SearchServiceTest, unittest.TestCase):
    """PageDataTestCase - PageData Unit tests.
    """
    SERVICE = PageData
    NUM_PARAMS = 4
    TEST_QUERY = "http://www.yahoo.com"

    def testBadParamValues(self):
        """Make sure bad parameter values are caught (%s)""" % self.SERVICE
        self.assertRaises(ValueError, self.srch.set_param, "results", "200")
        self.assertRaises(ValueError, self.srch.set_param, "start", -1)


#
# Test for InlinkData
#
class InlinkDataTestCase(PageDataTestCase):
    """InlinkDataTestCase - InlinkData Unit tests.
    """
    SERVICE = InlinkData
    NUM_PARAMS = 4
    TEST_QUERY = "http://www.yahoo.com"


#
# Finally, run all the tests
#
if __name__ == '__main__':
    unittest.main()



#
# local variables:
# mode: python
# indent-tabs-mode: nil
# py-indent-offset: 4
# end:
