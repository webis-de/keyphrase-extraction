"""Unit tests for all yahoo.search.video classes

"""

import unittest
from searchbase import SearchServiceTest

from yahoo.search.video import *


__revision__ = "$Id: video.py,v 1.2 2005/10/27 02:59:15 zwoop Exp $"
__version__ = "$Revision: 1.2 $"
__author__ = "Leif Hedstrom <leif@ogre.com>"
__date__ = "Wed Oct 26 19:45:00 PDT 2005"


#
# Test for video search
#
class VideoSearchTestCase(SearchServiceTest, unittest.TestCase):
    """VideoSearchTestCase - VideoSearch Unit tests.
    """
    SERVICE = VideoSearch
    NUM_PARAMS = 7


#
# Finally, run all the tests
#
if __name__ == '__main__':
    unittest.main()



#
# local variables:
# mode: python
# indent-tabs-mode: nil
# py-indent-offset: 4
# end:
