"""yahoo.search.audio - Audio Search services module

This module implements the the Audio Search web service, to do search
queries on various audio formats.

The supported classes of web searches are:
    
    ArtistSearch        - Information on a particular musical performer


An application ID (appid) is always required when instantiating a search
object. In addition, each search class takes different set of parameters,
as defined by this table:

               ArtistSearch  AlbumSearch  SongSearch  SongDLLocation
               ------------  -----------  ----------  --------------
    artist         [X]           [X]          [X]            .
    artistid       [X]           [X]          [X]            .
    type           [X]           [X]          [X]            .
    results        [X]           [X]          [X]           [X]
    start          [X]           [X]          [X]           [X]

    album           .            [X]          [X]            .
    albumid         .            [X]          [X]            .

    song            .             .           [X]           [X]
    songid          .             .           [X]            .

    source          .             .            .            [X]




Each of these parameter is implemented as an attribute of each
respective class. For example, you can set parameters like:

    from yahoo.search.web import ArtistSearch

    srch = AlbumSearch(app_id="something")
    srch.album = "Like"
    srch.results = 40

    for res in srch.parse_results():
       print res.YahooMusicPage

The PodcastSearch service takes a different kind of parameters, see
the documentation for this class for further details.
"""

import types

import yahoo.search
import yahoo.search.dom.audio


__revision__ = "$Id: audio.py,v 1.4 2005/10/27 17:22:56 zwoop Exp $"
__version__ = "$Revision: 1.4 $"
__author__ = "Leif Hedstrom <leif@ogre.com>"
__date__ = "Thu Oct 27 10:20:12 PDT 2005"


#
# Song download sources. XXX ToDo: These need descriptions.
#
DOWNLOAD_SOURCES = {'audiolunchbox':"",
                    'artistdirect':"",
                    'buymusic':"",
                    'dmusic':"",
                    'emusic':"",
                    'epitonic':"",
                    'garageband':"",
                    'itunes':"",
                    'yahoo':"",
                    'livedownloads':"",
                    'mp34u':"",
                    'msn':"",
                    'musicmatch':"",
                    'mapster':"",
                    'passalong':"",
                    'rhapsody':"",
                    'soundclick':"",
                    'theweb':""}

               
#
# Base class for some Audio Search classes
#
class _Audio(yahoo.search._Search):
    """Yahoo Search WebService - Common Audio Search parameters

    Setup the basic CGI parameters for some Audio Search services
    Since may of these services do not take a query argument, we
    can't subclass the Basic or Common search classes.
    """
    def _init_valid_params(self):
        """Initialize the set of valid parameters."""
        self._valid_params = {
            "artist" : (types.StringTypes, None, None, None, None, False),
            "artistid" : (types.StringTypes, None, None, None, None, False),
            "type" : (types.StringTypes, "all", str.lower,
                      ("all", "any", "phrase"), None, False),
            "results" : (types.IntType, 10, int, lambda x: x > -1 and x < 51,
                         "the range 1 to 50", False),
            "start" : (types.IntType, 1, int, lambda x: x > -1 and x < 1001,
                       "the range 1 to 1000", False),
            }

    def _get_download_sources(self):
        """Get the list of all supported download sources."""
        return DOWNLOAD_SOURCES
    download_sources = property(_get_download_sources, None, None,
                                "List of all supported download sources")


#
# ArtistSearch class
#
class ArtistSearch(_Audio):
    """ArtistSearch - perform a Yahoo Artist Search

    This class implements the Artist Search web service APIs. Allowed
    parameters are:
    
        artist     - The artist or partial artist string to search for
                     (UTF-8 encoded).
        artistid   - The specific id for an artist. Ids are internal to
                     the Music Search Service and will be returned with
                     artist references. One of artist or artistid is
                     always required.
        type       - The kind of search to submit:
                        * all returns results with all query terms.
                        * any resturns results with one or more of the
                          query terms.
                        * phrase returns results containing the query
                          terms as a phrase.
        results    - The number of results to return (1-50).
        start      - The starting result position to return (1-based).
                     The finishing position (start + results - 1) cannot
                     exceed 1000.


    Full documentation for this service is available at:

        http://developer.yahoo.net/search/audio/V1/artistSearch.html
    """
    NAME = "artistSearch"
    SERVICE = "AudioSearchService"
    _RESULT_FACTORY = yahoo.search.dom.audio.ArtistSearch

    def _init_valid_params(self):
        """Initialize the set of valid parameters."""
        super(ArtistSearch, self)._init_valid_params()
        self.require_oneof_params = ["artist", "artistid"]


#
# AlbumSearch class
#
class AlbumSearch(_Audio):
    """AlbumSearch - perform a Yahoo Album Search

    This class implements the Album Search web service APIs, which allows
    you to find information on music albums. Supported parameters are:
    
        artist     - The artist or partial artist string to search for
                     (UTF-8 encoded).
        artistid   - The specific id for an artist.
        album      - The album name to search for (UTF-8 encoded).
        albumid    - The specific id for an album. At least one of artist,
                     artistid, album or albumid is required.
        type       - The kind of search to submit:
                        * all returns results with all query terms.
                        * any resturns results with one or more of the
                          query terms.
                        * phrase returns results containing the query
                          terms as a phrase.
        results    - The number of results to return (1-50).
        start      - The starting result position to return (1-based).
                     The finishing position (start + results - 1) cannot
                     exceed 1000.


    Full documentation for this service is available at:

        http://developer.yahoo.net/search/audio/V1/albumSearch.html
    """
    NAME = "albumSearch"
    SERVICE = "AudioSearchService"
    _RESULT_FACTORY = yahoo.search.dom.audio.AlbumSearch

    def _init_valid_params(self):
        """Initialize the set of valid parameters."""
        super(AlbumSearch, self)._init_valid_params()
        self._valid_params.update({
            "album" : (types.StringTypes, None, None, None, None, False),
            "albumid" : (types.StringTypes, None, None, None, None, False),
            })
        self.require_oneof_params = ["artist", "artistid", "album", "albumid"]


#
# SongSearch class
#
class SongSearch(_Audio):
    """AlbumSearch - perform a Yahoo Album Search

    This class implements the Album Search web service APIs, which allows
    you to find information on music albums. Supported parameters are:
    
        artist     - The artist or partial artist string to search for
                     (UTF-8 encoded).
        artistid   - The specific id for an artist.
        album      - The album name to search for (UTF-8 encoded).
        albumid    - The specific id for an album.
        song       - The song title to search for (UTF-8 encoded).
        songid     - The specific id for a song. At least one of artist,
                     artistid, album, albumid, song or songid is required.
        type       - The kind of search to submit:
                        * all returns results with all query terms.
                        * any resturns results with one or more of the
                          query terms.
                        * phrase returns results containing the query
                          terms as a phrase.
        results    - The number of results to return (1-50).
        start      - The starting result position to return (1-based).
                     The finishing position (start + results - 1) cannot
                     exceed 1000.


    Full documentation for this service is available at:

        http://developer.yahoo.net/search/audio/V1/songSearch.html
    """
    NAME = "songSearch"
    SERVICE = "AudioSearchService"
    _RESULT_FACTORY = yahoo.search.dom.audio.SongSearch

    def _init_valid_params(self):
        """Initialize the set of valid parameters."""
        super(SongSearch, self)._init_valid_params()
        self._valid_params.update({
            "album" : (types.StringTypes, None, None, None, None, False),
            "albumid" : (types.StringTypes, None, None, None, None, False),
            "song" : (types.StringTypes, None, None, None, None, False),
            "songid" : (types.StringTypes, None, None, None, None, False),
            })
        self.require_oneof_params = ["artist", "artistid", "album", "albumid",
                                     "song", "songid"]


#
# SongDownlocaLocation class
#
class SongDownloadLocation(_Audio):
    """SongDownloadLocation - find places to download songs

    This class implements the Song Download Location web service APIs.
    Allowed parameters are:
    
        songid   - The specific id for a song.
        results  - The number of results to return (1-50).
        start    - The starting result position to return (1-based). The
                   finishing position (start + results - 1) cannot exceed
                   1000.
        source   - The source of the download. You may specify multiple
                   values, e.g. ["yahoo", "itunes"].


    Full documentation for this service is available at:

        http://developer.yahoo.net/search/audio/V1/artistSearch.html
    """
    NAME = "songDownloadLocation"
    SERVICE = "AudioSearchService"
    _RESULT_FACTORY = yahoo.search.dom.audio.SongDownloadLocation

    def _init_valid_params(self):
        """Initialize the set of valid parameters."""
        self._valid_params = {
            "songid" : (types.StringTypes, None, None, None, None, True),
            "results" : (types.IntType, 10, int, lambda x: x > -1 and x < 51,
                         "the range 1 to 50", False),
            "start" : (types.IntType, 1, int, lambda x: x > -1 and x < 1001,
                       "the range 1 to 1000", False),
            "source" : (types.StringTypes, [], str.lower,
                        self.download_sources.keys(), None, False),
            }


#
# PodcastSearch class
#
class PodcastSearch(yahoo.search._CommonSearch):
    """ImageSearch - perform a Yahoo Image Search

    This class implements the Image Search web service APIs. Allowed
    parameters are:
    
        query        - The query to search for (UTF-8 encoded).
        type         - The kind of search to submit (all, any or phrase).
        results      - The number of results to return (1-50).
        start        - The starting result position to return (1-based).
                       The finishing position (start + results - 1) cannot
                       exceed 1000.
        format       - Specifies the kind of image file to search for.
        adult_ok     - The service filters out adult content by default.
                       Enter a 1 to allow adult content.


    Supported formats are

        all       - All formats (default)
        aiff      - AIFF
        midi      - MIDI file
        mp3       - MP3 (MPEG-3) format
        msmedia   - Microsoft media
        quicktime - Apple QuickTime
        realmedia - Real media
        wav       - Wave file
        other     - Other


    Full documentation for this service is available at:

        http://developer.yahoo.net/audio/V1/podcastSearch.html
    """
    NAME = "podcastSearch"
    SERVICE = "AudioSearchService"
    _RESULT_FACTORY = yahoo.search.dom.audio.PodcastSearch

    def _init_valid_params(self):
        """Initialize the set of valid parameters."""
        super(PodcastSearch, self)._init_valid_params()
        self._valid_params.update({
            "format" : (types.StringTypes, "any", str.lower,
                        ("all", "any", "aiff", "midi", "msmedia", "quicktime",
                         "realmedia", "wav", "other"), None, False),
            })



#
# local variables:
# mode: python
# indent-tabs-mode: nil
# py-indent-offset: 4
# end:
