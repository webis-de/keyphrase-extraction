""" yahoo.search.version - Version information
"""

version = "2.0"
authorName = "Leif Hedstrom"
authorMail = "leif@ogre.com"
maintainerName = "Leif Hedstrom"
maintainerMail = "leif@ogre.com"
credits = """- The entire Yahoo search team, of course.
"""

author = "%s <%s>" % (authorName, authorMail)


__revision__ = "$Id: version.py,v 1.10 2005/10/26 20:32:27 zwoop Exp $"
__version__ = "$Revision: 1.10 $"
__author__ = "Leif Hedstrom <leif@ogre.com>"
__date__ = "Wed Oct 26 11:34:39 PDT 2005"



#
# local variables:
# mode: python
# indent-tabs-mode: nil
# py-indent-offset: 4
# end:
