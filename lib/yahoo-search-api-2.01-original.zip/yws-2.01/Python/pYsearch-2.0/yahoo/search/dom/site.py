"""DOM parser for Site Explorer results

Implement a simple DOM parsers for the Yahoo Search Web Services site
explorer APIs. This provides parser for the following classes:

    PageData      - Shows a list of all pages belonging to a domain
    InlinkData    - Shows the pages from other sites linking in to a page
"""


__revision__ = "$Id: site.py,v 1.1 2005/10/27 18:07:59 zwoop Exp $"
__version__ = "$Revision: 1.1 $"
__author__ = "Leif Hedstrom <leif@ogre.com>"
__date__ = "Wed Oct 26 15:03:18 PDT 2005"

from yahoo.search import dom


#
# DOM parser for PageData and InlinkData (same schema)
#
class PageData(dom.DOMResultParser):
    """PageData - DOM parser for PageData results

    Each result is a dictionary populated with the extracted data from the
    XML results. The following keys are always available:

        Title            - The title of the web page.
        Url              - The URL for the web page.
        ClickUrl         - The URL for linking to the page.


    Example:
        results = ws.parse_results(dom)
        for res in results:
            print "%s - %s" % (res.Title, res.Url)
    """
    def _init_res_fields(self):
        """Initialize the valid result fields."""
        self._res_fields = [('Title', None, None),
                            ('Url', None, None),
                            ('ClickUrl', None, None)]



#
# local variables:
# mode: python
# indent-tabs-mode: nil
# py-indent-offset: 4
# end:
