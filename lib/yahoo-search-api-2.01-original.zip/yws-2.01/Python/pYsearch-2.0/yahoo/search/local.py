"""yahoo.search.local - Local Search services module

This module implements the the Local Search web service, to do search
queries on various local formats. There is currently only one class
implemented, LocalSearch.

An application ID (appid) is always required when instantiating a search
object. Additional parameters are documented in the LocalSearch class.

Example:

    from yahoo.search.local import LocalSearch

    srch = LocalSearch(app_id="something", zip="94019", query="BevMo")
    srch.results = 1

    for res in srch.parse_results():
       print res.MapUrl
"""

import types

import yahoo.search
import yahoo.search.dom.local


__revision__ = "$Id: local.py,v 1.2 2005/10/17 23:11:26 zwoop Exp $"
__version__ = "$Revision: 1.2 $"
__author__ = "Leif Hedstrom <leif@ogre.com>"
__date__ = "Mon Oct 17 15:29:37 PDT 2005"


#
# LocalSearch class
#
class LocalSearch(yahoo.search._BasicSearch):
    """LocalSearch - perform a Yahoo Local Search

    This class implements the Local Search web service APIs. Allowed
    parameters are:
    
        query        - The query to search for.
        results      - The number of results to return (1-20).
        start        - The starting result position to return (1-based).
                       The finishing position (start + results - 1) cannot
                       exceed 1000.
        sort         - Sorts the results by the chosen criteria.
        radius       - How far from the specified location to search for
                       the query terms.
        street       - Street name. The number is optional.
        city         - City name.
        state        - The United States state. You can spell out the
                       full state name or you can use the two-letter
                       abbreviation.
        zip          - The five-digit zip code, or the five-digit code
                       plus four-digit extension.
        location     - Free form field for location (see below).
        latitude     - Latitude of the starting location (-90.0 - 90.0).
        longitude    - Longitude of the starting location (-180.0 - 180.0).


    If both latitude and longitude are specified, they will take priority
    over all other location data. If only one of latitude or longitude is
    specified, both will be ignored.
                        
    Full documentation for this service is available at:

        http://developer.yahoo.net/local/V1/localSearch.html
    """
    NAME = "localSearch"
    SERVICE = "LocalSearchService"
    SERVER = "api.local.yahoo.com"
    _RESULT_FACTORY = yahoo.search.dom.local.LocalSearch

    def _init_valid_params(self):
        """Initialize the set of valid parameters."""
        super(LocalSearch, self)._init_valid_params()
        self._valid_params.update({
            "results" : (types.IntType, 10, int, range(1, 21),
                         "the range 1 to 20", False),
            "sort" : (types.StringTypes, "relevance", str.lower,
                      ("relevance", "title", "distance", "rating"), None, False),
            "radius" : (types.FloatType, None, float, None, None, False),
            "street" : (types.StringTypes, None, None, None, None, False),
            "city" : (types.StringTypes, None, None, None, None, False),
            "state" : (types.StringTypes, None, None, None, None, False),
            "zip" : (types.StringTypes, None, None, None, None, False),
            "location" : (types.StringTypes, None, None, None, None, False),
            "latitude" : (types.FloatType, None, float,
                          lambda x: x > (-90) and x < 90,
                          "-90 < val < 90", False),
            "longitude" : (types.FloatType, None, float,
                           lambda x: x > (-180) and x < 180,
                           "-180 < val < 180", False),
            })



#
# local variables:
# mode: python
# indent-tabs-mode: nil
# py-indent-offset: 4
# end:
