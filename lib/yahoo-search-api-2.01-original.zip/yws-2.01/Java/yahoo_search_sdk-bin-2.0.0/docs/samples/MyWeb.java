import com.yahoo.myweb.*;

import java.io.IOException;

/**
 * Code sample to demonstrate using the Yahoo! Java API to query the
 * My Web system.
 *
 * @author Ryan Kennedy
 */
public class MyWeb {
    public static void main(String[] args) {
        // Create the search client. Pass it your application ID.
        MyWebClient client = new MyWebClient("javasdktest");

        // Create the web search request. In this case we're searching for
        // java-related hits.
        ListFoldersRequest request = new ListFoldersRequest("rckenned");

        try {
            // Execute the listing.
            ListFoldersResults results = client.listFolders(request);

            // Print out how many folders were found.
            System.out.println("Found " + results.getTotalResultsAvailable() +
                    " folders! Displaying the first " +
                    results.getTotalResultsReturned() + ".");

            // Iterate over the folders.
            for (int i = 0; i < results.listResults().length; i++) {
                ListFolderResult result = results.listResults()[i];

                // Print out the folder name and URL count.
                System.out.println("   " + (i + 1) + ": " + result.getTitle() + " (" +
                        result.getUrlCount() + " URLs)");
            }
        }
        catch (IOException e) {
            // Most likely a network exception of some sort.
            System.err.println("Error calling Yahoo! Search Service: " +
                    e.toString());
            e.printStackTrace(System.err);
        }
        catch (MyWebException e) {
            // An issue with the XML or with the service.
            System.err.println("Error calling Yahoo! My Web Service: " +
                    e.toString());
            e.printStackTrace(System.err);
        }
    }
}